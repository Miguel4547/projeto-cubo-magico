// 1. CONFIGURAÇÃO DA CENA, CÂMERA E RENDERIZADOR
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x222222);

const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(5, 5, 7); // Posição angular ideal

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// 2. CONTROLES DA CÂMERA (OrbitControls - Requisito obrigatório)
const controls = new THREE.OrbitControls(camera, renderer.domElement);
controls.enableDamping = true; 

// Iluminação
const luzAmbiente = new THREE.AmbientLight(0xffffff, 0.8);
scene.add(luzAmbiente);
const luzDirecional = new THREE.DirectionalLight(0xffffff, 0.4);
luzDirecional.position.set(5, 10, 7);
scene.add(luzDirecional);

// 3. CORES OFICIAIS DO CUBO MÁGICO
const cores = [
  0xb71212, // Direita (X+): Vermelho
  0x0046ad, // Esquerda (X-): Azul
  0xffffff, // Cima (Y+): Branco
  0xffd500, // Baixo (Y-): Amarelo
  0x009b48, // Frente (Z+): Verde
  0xff5800  // Trás (Z-): Laranja
];
const materiaisCubo = cores.map(cor => new THREE.MeshStandardMaterial({ color: cor }));

// 4. CRIANDO OS 27 CUBINHOS (3x3x3)
const cubinhos = [];
for (let x = -1; x <= 1; x++) {
  for (let y = -1; y <= 1; y++) {
    for (let z = -1; z <= 1; z++) {
      const geometria = new THREE.BoxGeometry(0.95, 0.95, 0.95);
      const cubo = new THREE.Mesh(geometria, materiaisCubo);
      cubo.position.set(x, y, z);
      scene.add(cubo);
      cubinhos.push(cubo);
    }
  }
}

// 5. LÓGICA DE ROTAÇÃO DAS FACES USANDO THREE.GROUP (Dica do slide)
let animando = false;

function girarFace(eixo, valor) {
  if (animando) return;
  animando = true;

  const grupoFace = new THREE.Group();
  scene.add(grupoFace);

  // Filtra os cubinhos pertencentes à face no espaço global
  const faceSelecionada = cubinhos.filter(c => {
    const posicaoGlobal = new THREE.Vector3();
    c.getWorldPosition(posicaoGlobal);
    return Math.round(posicaoGlobal[eixo]) === valor;
  });

  // Agrupa temporariamente
  faceSelecionada.forEach(c => grupoFace.attach(c));

  let anguloAlvo = Math.PI / 2; // 90 graus
  let anguloAtual = 0;
  const velocidade = 0.05;

  function animar() {
    if (anguloAtual < anguloAlvo) {
      grupoFace.rotation[eixo] += velocidade;
      anguloAtual += velocidade;
      requestAnimationFrame(animar);
    } else {
      grupoFace.rotation[eixo] = anguloAlvo;

      // Desagrupa atualizando a posição real dos cubinhos no mundo
      const copiaFilhos = [...grupoFace.children];
      copiaFilhos.forEach(c => scene.attach(c));

      scene.remove(grupoFace);
      animando = false;
    }
  }
  animar();
}

// 6. DETECÇÃO DE CLIQUES NOS BOTÕES
document.getElementById("btnU").addEventListener("click", () => girarFace("y", 1));
document.getElementById("btnF").addEventListener("click", () => girarFace("z", 1));

// 7. DETECÇÃO DE TECLADO
window.addEventListener("keydown", e => {
  if (animando) return;
  if (e.key === "u" || e.key === "U") girarFace("y", 1);
  if (e.key === "f" || e.key === "F") girarFace("z", 1);
});

// 8. RESPONSIVIDADE
window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

// 9. LOOP DE EXECUÇÃO
function loop() {
  requestAnimationFrame(loop);
  controls.update(); 
  renderer.render(scene, camera);
}
loop();